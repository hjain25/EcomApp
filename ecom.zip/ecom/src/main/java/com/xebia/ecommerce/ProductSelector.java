package com.xebia.ecommerce;

import java.util.*;

public class ProductSelector {

	public void getProduct(String productType, int customerCode) {

		double totalDiscountedAmount = 0.0;
		double nonDiscountedAmount = 0.0;
		DiscountCalculator discountcalculator = new DiscountCalculator();
		Scanner sc = new Scanner(System.in);
		String product = "";

		List<String> productTypes = new ArrayList();
		productTypes.add("grocery");
		productTypes.add("clothing");
		productTypes.add("footwears");
		productTypes.add("electronic");

		HashMap<String, Integer> clothes = new HashMap<String, Integer>();
		clothes.put("shirt", 200);
		clothes.put("jeans", 900);
		clothes.put("jacket", 3000);
		clothes.put("cap", 150);

		HashMap<String, Integer> footwears = new HashMap<String, Integer>();
		footwears.put("shoes", 700);
		footwears.put("sandals", 435);
		footwears.put("slippers", 200);
		footwears.put("formal shoes", 800);

		HashMap<String, Integer> electronics = new HashMap<String, Integer>();
		electronics.put("washing machine", 7000);
		electronics.put("mobile", 10000);
		electronics.put("toaster", 1900);
		electronics.put("dell laptop", 70000);

		HashMap<String, Integer> grocery = new HashMap<String, Integer>();
		grocery.put("peas", 20);
		grocery.put("rice", 18);
		grocery.put("spices", 44);
		grocery.put("floor", 22);

		String[] selectedProductTypes = productType.split(",");

		for (String type : selectedProductTypes) {

			if (type.equals("clothing")) {
				System.out.println("please enter products from > " + clothes);

				while (!product.equals("clothes done")) {
					product = sc.nextLine();
					if (!product.equals("clothes done")) {
						totalDiscountedAmount += clothes.get(product)
								.doubleValue();
					}
				}

			} else if (type.equals("footwears")) {
				System.out.println("please enter products from > " + footwears);
				while (!product.equals("footwears done")) {
					product = sc.nextLine();
					if (!product.equals("footwears done")) {
						totalDiscountedAmount += footwears.get(product)
								.doubleValue();
					}
				}
			} else if (type.equals("electronics")) {
				System.out.println("please enter products from > "
						+ electronics);
				while (!product.equals("electronics done")) {
					product = sc.nextLine();
					if (!product.equals("electronics done")) {
						totalDiscountedAmount += electronics.get(product)
								.doubleValue();
					}
				}
			} else if (type.equals("grocery")) {
				System.out.println("please enter products from > " + grocery);

				while (!product.equals("grocery done")) {
					product = sc.nextLine();
					if (!product.equals("grocery done")) {
						nonDiscountedAmount += grocery.get(product)
								.doubleValue();
					}
				}
			} else {
				System.out.println("Item out of stock");
			}
		}

		discountcalculator.calculateDiscount(totalDiscountedAmount,
				nonDiscountedAmount, customerCode);

		// HashMap<String, Integer> customerBucket = new HashMap<String,
		// Integer>();

	}
}
