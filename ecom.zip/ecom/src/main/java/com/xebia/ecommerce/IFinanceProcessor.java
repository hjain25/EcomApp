package com.xebia.ecommerce;

public interface IFinanceProcessor {
	void calculateDiscount(double totalRate,double nonDiscoutedRate,int customerCode);
	void generateBill(double totalRate,double discountedRate,double nonDiscountedRate);
}
