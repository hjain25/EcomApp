package com.xebia.ecommerce;

public interface IFinanceProcessor {
	void calculateDiscount(double totalRate,double nonDiscoutedRate);
	void generateBill(double totalRate,double discountedRate,double nonDiscountedRate);
}
