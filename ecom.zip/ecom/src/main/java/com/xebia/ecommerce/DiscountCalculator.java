package com.xebia.ecommerce;

import java.util.*;

public class DiscountCalculator implements IFinanceProcessor {

	public void calculateDiscount(double totalDiscountedAmount,
			double nonDiscountedAmount) {
		System.out.println("Please enter your customer type : ");
		System.out.println("If you are employee,type 1 for 30% discount >");
		System.out.println("If you are an affiliate,type 2 for 10% discount >");
		System.out
				.println("If you are customer for min 2 years, type 3 for 5% discount >");
		System.out.println("type 4 for others");

		Scanner sc = new Scanner(System.in);
		int customerCode = sc.nextInt();

		double discountAmount;

		if (totalDiscountedAmount == 0)
			generateBill(nonDiscountedAmount);
		else {
			if (customerCode == 1) {
				// give 30% discount
				System.out.println("you have got 30% discount"
						+ totalDiscountedAmount);
				discountAmount = totalDiscountedAmount * 30 / 100;

			} else if (customerCode == 2) {
				// give 10% discount
				System.out.println("you have got 10% discount");

				discountAmount = totalDiscountedAmount * 10 / 100;

			} else if (customerCode == 3) {
				// give 5$ discount
				System.out
						.println("you have got 5$ less on as per your total bill");
				discountAmount = totalDiscountedAmount * 5 / 100;
			} else {
				discountAmount = 0;
			}

			generateBill(totalDiscountedAmount, discountAmount,
					nonDiscountedAmount);
		}
	}

	public void generateBill(double totalDiscountedAmount,
			double discountAmount, double nonDiscountedAmount) {
		double finalRebateOnBill = ((((totalDiscountedAmount - discountAmount) + nonDiscountedAmount)) / 100) * 5;
		double finalBill = ((((totalDiscountedAmount - discountAmount) + nonDiscountedAmount)))
				- finalRebateOnBill;
		System.out.println("Your Total Bill Payable Amount is :" + (finalBill));
		System.out.println("Thanks For Visiting !");
	}

	public void generateBill(double nonDiscountedAmount) {
		double finalRebateOnBill = (nonDiscountedAmount / 100) * 5;
		double finalBill = nonDiscountedAmount - finalRebateOnBill;
		System.out.println("your total bill is : " + finalBill);
	}
}
