package com.xebia.ecommerce;

import java.util.Scanner;

public class Buyer {

	ProductSelector productSelector;
	static String productType;
	static int customerCode;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Buyer buy = new Buyer();
		buy.getCustomerData();
	}

	public void getCustomerData() {
		Scanner sc = new Scanner(System.in);
		System.out.println("please enter your choice of category and total Products");
		productType = sc.nextLine();
		System.out.println("please select your customer code from 1 ,2 & 3 ");
		customerCode = sc.nextInt();
		buyProduct();
	}

	public void buyProduct() {
		productSelector = new ProductSelector();
		productSelector.getProduct(productType,customerCode);
	}
}
